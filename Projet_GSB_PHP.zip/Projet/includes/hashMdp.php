<?php
    require_once ('includes/Cdao.php');
    require_once ('includes/Cvisiteurs.php');

    $données = "SELECT id, mdp FROM employe";

    $visiteurs = new Cvisiteurs();
    $cdao = new Cdao();

    function hasherMotDePasse($motDePasse, $sid)
    {
        $odao = new Cdao();
        $salt = random_bytes(length:16);
        $salt = bin2hex($salt);
        $motDePassehash = hash(algo:'sha512', data: $motDePasse . $salt);
        $query ="Update employe SET salt='". $salt. "', hashMdp='". $motDePasse."' XHERE id='".$sid."';";
        $odao->update($query);

    }

    $result = $cdao->gettabDataFromSql($données);

    foreach($result as $row) {
        hasherMotDePasse($row['mdp'], $row['id'];)
    }
    