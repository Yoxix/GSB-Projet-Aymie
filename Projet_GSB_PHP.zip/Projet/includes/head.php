<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1"> <!-- apparemment initial-scale=1 suffit sans width -->
   
    <!-- CSS personnel -->
    <link href="includes/style.css" rel="stylesheet">
    
    <!-- liens vers biblio CSS et JS BOOTSTRAP en ligne (CDN) -->
    <!--<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>-->
    
    <!-- liens vers biblio CSS et JS BOOTSTRAP en local -->
    <link href="lib/bootstrap-5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="lib/bootstrap-5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</head>



