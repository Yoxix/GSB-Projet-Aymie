<?php


require_once 'mesClasses/Cvisiteurs.php';

if (isset($_POST['username']) && isset($_POST['pwd'])) {
    $lesVisiteurs = new Cvisiteurs();
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $password = filter_input(INPUT_POST, 'pwd', FILTER_SANITIZE_STRING);

    $ovisiteur = $lesVisiteurs->verifierInfosConnexion($username, $password);

    if ($ovisiteur) 
    {
        $_SESSION['visiteur'] = serialize($ovisiteur);
        header('Location: saisirFicheFrais.php');
    } 
    elseif ($ovisiteur == "directeurregion")
    {
        $_SESSION['chefregion'] == serialize($ovisiteur);
        header('Location: afficheMedPro.php');
    }
    else
    {
        $errorMsg = "Login/Mot de passe incorrect";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion lab GSB</title>
</head>
<body>
<header>
    <h2>Connexion lab GSB</h2>
</header>

<form action="" method="POST">
    <div>
        <label for="username">Login:</label>
        <input type="text" id="username" placeholder="Saisir votre login" name="username" required>
    </div>
    <div>
        <label for="pwd">Mot de passe:</label>
        <input type="password" id="pwd" placeholder="Saisir votre mot de passe" name="pwd" required>
    </div>
    <div>
        <input type="checkbox" id="remember" name="remember">
        <label for="remember">Se souvenir de moi</label>
    </div>
    <button type="submit">Se connecter</button>
</form>
</body>
</html>
