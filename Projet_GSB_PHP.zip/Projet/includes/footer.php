<footer title="copyright">
    <p>Copyright &copy GSB</p>
</footer>

