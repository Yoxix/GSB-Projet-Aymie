<?php if (isset($successMsg)): ?>
    <div class="alert alert-success container"><?= $successMsg ?></div>
<?php endif; ?>
<?php if (isset($errorMsg)): ?>
    <div class="alert alert-danger container"><?= $errorMsg ?></div>
<?php endif; ?>
 

