<?php
public function getTabVisiteursParNomEtVille($sdebutFin, $spartieNom, $sville) {
    $tabVisiteursByVilleNom = [];
    foreach ($this->ocollVisiteurs as $ovisiteur) {
        if ((strtolower($ovisiteur->ville) == strtolower($sville)) || $sville == 'toutes') {
            if ($spartieNom != '*') {
                if ($sdebutFin == "debut") {
                    $nomExtrait = substr($ovisiteur->nom, 0, strlen($spartieNom));
                    if (strtolower($nomExtrait) == strtolower($spartieNom)) {
                        $tabVisiteursByVilleNom[] = $ovisiteur;
                    }
                } elseif ($sdebutFin == "fin") {
                    $nomExtrait = substr($ovisiteur->nom, -strlen($spartieNom), strlen($spartieNom));
                    if (strtolower($nomExtrait) == strtolower($spartieNom)) {
                        $tabVisiteursByVilleNom[] = $ovisiteur;
                    }
                } elseif ($sdebutFin == "nimporte") {
                    $i = 0;
                    $tab = str_split($ovisiteur->nom);
                    foreach ($tab as $caract) {
                        $nomExtrait = substr($ovisiteur->nom, $i, strlen($spartieNom));
                        if (strtolower($nomExtrait) == strtolower($spartieNom)) {
                            $tabVisiteursByVilleNom[] = $ovisiteur;
                            break;
                        }
                        $i++;
                    }
                }
            } else {
                $tabVisiteursByVilleNom[] = $ovisiteur;
            }
        }
    }
    return $tabVisiteursByVilleNom;

