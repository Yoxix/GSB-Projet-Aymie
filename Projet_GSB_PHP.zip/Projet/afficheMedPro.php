<!DOCTYPE html>
 <?php session_start(); ?>
<html>
    <?php 
        require_once 'includes/head.php';
        
        require_once 'mesClasses/Cvisiteurs.php';
        require_once 'mesClasses/Cemploye.php';
        require_once 'mesClasses/Cregion.php';
        require_once 'includes/functions.php';

        
        
        if (!isset($_SESSION['chefregion'])) {
            header('Location: seConnecter.php');
            exit;
        }
        
        $directeurRegion = unserialize($_SESSION['chefregion']);
        if ($directeurRegion === false || $directeurRegion === null) {
            header('Location: seConnecter.php');
            exit;
        }
        
        // Affichage des informations du directeur région
        var_dump($directeurRegion);
    ?>
<body>
    <div class="container">
        <header title="listevisiteur"></header>
        <?php require_once 'includes/navBar.php'; ?>
    

    <h1>Affectation des médicaments aux visiteurs médicaux</h1>

<form id="medForm">

    <input type="checkbox" name="medicament[]" value="med1"> Doliprane
    <input type="checkbox" name="medicament[]" value="med2"> Olumian
    <input type="checkbox" name="medicament[]" value="med1"> Spasfon
    <input type="checkbox" name="medicament[]" value="med2"> Smecta
    <input type="button" value="Affecter" onclick="affecterMedicaments()">
</form>

<!-- Div pour afficher les résultats de l'AJAX -->
<div id="result"></div>

<!-- Script AJAX pour insérer les données -->
<script>
function affecterMedicaments() {
    // Récupérer les données du formulaire
    var formData = new FormData(document.getElementById("medForm"));
    
    //Envoyer les données via AJAX
    $.ajax({
         url: "insert.php",
         type: "POST",
         data: formData,
         processData: false,
         contentType: false,
         success: function(response) {
             $("#result").html(response);
         }
     });
}
</script>
</div>

</body>
</html>