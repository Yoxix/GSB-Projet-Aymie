<html>
    <?php 
        require_once 'includes/head.php';        
        require_once './mesClasses/Cvisiteurs.php'; 
        
        session_start();
    ?>
<body>
    <div class="container">
        <header title="listevisiteur"></header>
        <?php require_once 'includes/navBar.php'; ?>
    
<?php
// Récupérer les données envoyées via AJAX
$mois = $_POST['mois'];
$medicaments = $_POST['medicament'];
$nom = $_POST['nom'];
$prenom = $_POST['prenom'];

// Insérer les données dans la base de données

$sql = "INSERT INTO affectations (mois, medicaments, nom, prenom) VALUES ('$mois', '$medicaments', '$nom', '$prenom')";
$result = mysqli_query($conn, $sql);

// Vérifier si l'insertion a réussi
if ($result) 
{
    echo "Affectation des médicaments réussie !";
} else 
{
    echo "Erreur lors de l'affectation des médicaments : " . mysqli_error($conn);
}

?>
</body>
</html>