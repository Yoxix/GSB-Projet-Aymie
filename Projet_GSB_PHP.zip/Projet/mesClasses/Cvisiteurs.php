<?php

require_once 'Cdao.php';
require_once 'Cemploye.php';

class Cvisiteur extends Cemploye {
    public $ville;

    public function __construct($sid, $snom, $sprenom, $slogin, $smdp, $sville) {
        parent::__construct($sid, $slogin, $snom, $sprenom, $smdp);
        $this->ville = $sville;
    }
}

class Cvisiteurs {
    public $ocollVisiteursByLogin;

    public function __construct() {
        $this->ocollVisiteursByLogin = [];
        

        try {
            $dao = new Cdao();
            $lesVisiteurs = $dao->getTabDataFromSql("SELECT * FROM visiteur v INNER JOIN employe e ON v.id = e.id");

            if (is_array($lesVisiteurs)) {
                foreach ($lesVisiteurs as $ligne) {
                    $ovisiteur = new Cvisiteur($ligne["id"], $ligne["nom"], $ligne["prenom"], $ligne["login"], $ligne["mdp"], $ligne["ville"]);
                    $this->ocollVisiteursByLogin[$ovisiteur->slogin] = $ovisiteur;
                }
            }
        } catch (PDOException $e) {
            $msg = 'ERREUR PDO dans ' . $e->getFile() . ' L.' . $e->getLine() . ' : ' . $e->getMessage();
            die($msg);
        }
    }

    public function getVisiteurByLogin($login) {
        return $this->ocollVisiteursByLogin[$login] ?? null;
    }

    public function verifierInfosConnexion($username, $password) {
        $ovisiteur = $this->getVisiteurByLogin($username);
        if ($ovisiteur && $ovisiteur->smdp === $password) {
            return $ovisiteur;
        }
        return null;
    }
    public function getTabVisiteursParNomEtVille($sdebutFin, $spartieNom, $sville)
    {
        $tabVisiteursByVilleNom = [];
        foreach ($this->ocollVisiteursByLogin as $ovisiteur) {
            if ((strtolower($ovisiteur->sville) == strtolower($sville)) || $sville == 'toutes') {
                if ($spartieNom != '*') {
                    if ($sdebutFin == "debut") {
                        $nomExtrait = substr($ovisiteur->snom, 0, strlen($spartieNom)); // Changer ici
                        if (strtolower($nomExtrait) == strtolower($spartieNom)) {
                            $tabVisiteursByVilleNom[] = $ovisiteur;
                        }
                    } elseif ($sdebutFin == "fin") {
                        $nomExtrait = substr($ovisiteur->snom, -strlen($spartieNom), strlen($spartieNom)); // Changer ici
                        if (strtolower($nomExtrait) == strtolower($spartieNom)) {
                            $tabVisiteursByVilleNom[] = $ovisiteur;
                        }
                    } elseif ($sdebutFin == "nimporte") {
                        $i = 0;
                        $tab = str_split($ovisiteur->snom);
                        foreach ($tab as $caract) {
                            $nomExtrait = substr($ovisiteur->snom, $i, strlen($spartieNom)); // Changer ici
                            if (strtolower($nomExtrait) == strtolower($spartieNom)) {
                                $tabVisiteursByVilleNom[] = $ovisiteur;
                                break;
                            }
                            $i++;
                        }
                    }
                } else {
                    $tabVisiteursByVilleNom[] = $ovisiteur;
                }
            }
        }
        return $tabVisiteursByVilleNom;
    }


    public function getVisiteursTrie() {
        $otrie = new Ctri();
        $ocollVisiteursTrie = $otrie->TriTableau($this->ocollVisiteursByLogin, "nom");
        return $ocollVisiteursTrie;
    }

    function getVilleVisiteur()
    {
        return $this->tabVilleVisiteur;
    }
}

?>
