<?php
class Cenregistrement {
    
    public $id;
    public $idMed;
    public $dates;
    
    function __construct($sid, $sidMed, $sdates){
        $this->id = $sid;
        $this->idMed = $sidMed;
        $this->dates = $sdates;
    }
}

?>