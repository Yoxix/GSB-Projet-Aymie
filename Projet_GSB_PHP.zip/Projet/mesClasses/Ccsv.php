<?php

class Ccsv
{
    public function creerFichierCSV($stabTrie) {
        //récupération du handle sur le fichier
        $fp = fopen('employe.csv', 'w');

        //écrire les en-têtes du CSV
        fputcsv()
    }
}

?>