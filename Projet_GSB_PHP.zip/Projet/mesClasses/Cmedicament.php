<?php
class Cmedicament {
    
    public $idMed;
    public $designationMed;
    public $niveauDanger;
    public $descMed;
    public $dateSortie;
    public $cheminImageMed;
    
    function __construct($sidMed, $sdesignationMed, $sniveauDanger, $sdescMed, $sdateSortie, $scheminImageMed){
        $this->idMed = $sidMed;
        $this->designationMed = $sdesignationMed;
        $this->niveauDanger = $sniveauDanger;
        $this->descMed = $sdescMed;
        $this->dateSortie = $sdateSortie; 
        $this->cheminImageMed = $scheminImageMed; 
    }
}

?>