<?php
class Cdirecteurregion extends Cemploye {

    public $idDirecteur;
    public $idRegion;

   /* function __construct($id, $login, $nom, $prenom, $mdp, $ville, $hashMdp, $salt, $region)
    {
        parent::__construct($id, $login, $nom, $prenom, $mdp, $ville, $hashMdp, $salt);
    }*/

}

class Cdirecteurregions {

        public function __construct() {
            $this->role = "directeurregion";
        try
        {
            $dao = new Cdao();
            $directeurregion = $dao->getTabDataFromSql("SELECT * FROM directeurregion dr INNER JOIN employe e ON dr.id = e.id");

            if (is_array($directeurregion)) {
                foreach ($this->ocolldirecteurregion as $directeurregion) {
                    $odirecteur = new Cdirecteurregion($ligne["iddirecteur"], $ligne["idregion"]);
                    $this->ocollDirecteur[] = $oDirecteur;
                }
            }

        }
        catch (PDOException $e) {
            $msg = 'ERREUR PDO dans ' . $e->getFile() . ' L.' . $e->getLine() . ' : ' . $e->getMessage();
            die($msg);
        }

    }




    public function verifierInfosConnexion($username, $password)
    {
        foreach ($this->ocollDirecteurRegion as $odirecteurregion) {
            if ($odirecteurregion->login == $username && $odirecteurregion->mdp == $password) {
                return $odirecteurregion;
            }
        }
        return null;
    }
}

?>