<?php
class Cregion {

    public $idRegion;
    public $libelle;
}

class Cregions
{

    private $ocollRegion;

    function __construct()
    {

        $this->ocollRegion = [];
        $dao = new Cdao();
        $ligneRegion = $dao->getTabObjetFromSql("SELECT * FROM region", 'Cregion');

        foreach ($ligneRegion as $oregion) {
            $this->ocollRegion[] = $oregion;
        }
    
    }

    function getRegionById($id)
    {
        foreach ($this->ocollRegion as $oregion) 
        {
            if ($oregion->idRegion = $id) 
            {
                return $region;
            }
            return null;
        }
    }

    function getVisiteurByRegionDirecteur($idRegion)
    {
        $dao = new Cdao();
        $query = "SELECT visiteur.id, employe.nom, employe.prenom
                  FROM visiteur
                  INNER JOIN employe
                  ON visiteur.id = employe.id
                  WHERE visiteur.idRegion = idRegion";

        
        return $query;
    }

    function getRegionByVisiteur($idRegion)
    {
        foreach($this->ocollRegion as $uneRegion)
        {
            if($uneRegion->idRegion == $idRegion)
            {
                return $uneRegion;
            }
        }
    }

    function getVisiteurByIdRegion($idRegion)
    {
        $dao = new Cdao();
        $ovisiteur = $dao-> getVisiteurByIdRegion($idRegion);
        return $ovisiteur;
    }
}

?>