<?php

abstract class Cemploye
{
    public $sid;
    public $slogin;
    public $snom;
    public $sprenom;
    public $smdp;

    function __construct($sid, $slogin, $snom, $sprenom, $smdp) {
        $this->sid = $sid;
        $this->slogin = $slogin;
        $this->snom = $snom;
        $this->sprenom = $sprenom;
        $this->smdp = $smdp;
    }
}



?>