<?php
class Ccomptable {
    
    public $id;
    public $nom;
    public $prenom;
    public $login;
    public $mdp;
    public $adresse;
    public $cp;
    public $ville;
    public $dateEmbauche;


    
    function __construct($sid,$snom, $sprenom, $slogin, $smdp, $sadresse, $scp, $sville, $sdateEmbauche){
        $this->id = $sid;
        $this->nom = $snom;
        $this->prenom = $sprenom;
        $this->login = $slogin;
        $this->mdp = $smdp; 
        $this->adresse = $sadresse;
        $this->cp = $scp;  
        $this->ville = $sville;
        $this->dateEmbauche = $sdateEmbauche;

 
    }
}

?>