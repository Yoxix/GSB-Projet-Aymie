<?php

phpInfo();

