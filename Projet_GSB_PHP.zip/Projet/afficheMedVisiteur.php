<html>
    <?php 
        require_once 'includes/head.php';        
        require_once './mesClasses/Cvisiteurs.php'; 
        
        session_start();
    ?>
<body>
    <div class="container">
        <header title="listevisiteur"></header>
        <?php require_once 'includes/navBar.php'; ?>


        <table>
    <tr>
        <td>med1</td>
        <td>med 2</td>
    </tr>
    <tr>
        <td>med3</td>
        <td>med4</td>
    </tr>
</table>



</body>
</html>